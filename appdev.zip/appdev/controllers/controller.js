exports.home = (req, res) => {
    res.render('home', { title: 'Home Page'});
};

exports.about = (req, res) => {
    res.render('about', {title: 'About Page'});
};

exports.contact = (req, res) => {
    res.render('contact', {title: 'Contact Page'});
};

exports.services = (req, res) => {
    res.render('services', {title: 'Services Page'});
};

exports.faq = (req, res) => {
    res.render('faq', {title: 'FAQ Page'});
};